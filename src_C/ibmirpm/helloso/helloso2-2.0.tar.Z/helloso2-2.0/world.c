#include <stdio.h>
void world(void){
	printf("world.\n");
}
