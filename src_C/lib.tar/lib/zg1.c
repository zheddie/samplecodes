
#include <stdio.h>
#include <unistd.h>
#include <string.h>

static char str[] = "Hello from echowrite\n";

int echowrite(){
	int len = strlen(str);
	kwrite(STDOUT_FILENO,str,len);
	return(0);
}
