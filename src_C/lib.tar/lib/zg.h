#ifndef _ZG_HEADER_
#define _ZG_HEADER_

int echoprintf();
int echowrite();

#endif
