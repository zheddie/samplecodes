#include <stdio.h>
#include "zg.h"

int main(){
	echoprintf();
	echowrite();
}
