#include "world.h"
int main(void){
	hello();
	return(0);
}
