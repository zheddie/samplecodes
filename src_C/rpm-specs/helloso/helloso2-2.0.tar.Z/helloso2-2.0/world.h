#ifndef _HELLO_WORLD_H_
#define _HELLO_WORLD_H_
void world(void);
void hello(void);
#endif
