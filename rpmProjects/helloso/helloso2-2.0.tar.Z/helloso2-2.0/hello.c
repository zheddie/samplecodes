#include <stdio.h>
#include "world.h"
void hello(void){
	printf("hello \n");
	world();
}
