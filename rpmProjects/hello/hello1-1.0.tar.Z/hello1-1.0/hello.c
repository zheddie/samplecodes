#include <stdio.h>
int main(void){
	printf("Hello RPM!\n");
	return(0);
}
