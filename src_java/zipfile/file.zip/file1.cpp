This is from .cpp file.
But it's just a text for test. 

bye.